﻿namespace WebApi
{
    public class SearchModel
    {
        public string Url { get; set; }
        public string Keyword { get; set; }
    }
}
